def search(query: str, top_k: int = 5): return []
