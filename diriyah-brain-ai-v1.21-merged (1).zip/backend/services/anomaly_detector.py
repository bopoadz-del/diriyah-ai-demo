def detect_anomalies(data_stream: list): return []
