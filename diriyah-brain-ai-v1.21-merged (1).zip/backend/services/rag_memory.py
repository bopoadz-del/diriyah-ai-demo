def retrieve_with_memory(query: str): return {'context': [], 'answer': None}
