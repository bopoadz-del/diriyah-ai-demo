def predict_schedule_delay(schedule_data: dict): return {'risk_of_delay': 0.0}
def predict_cost_overrun(cost_data: dict): return {'risk_of_overrun': 0.0}
