def normalize_entry(entry: dict): return entry
