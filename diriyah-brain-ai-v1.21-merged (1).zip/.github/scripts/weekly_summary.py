
import os
import sys
import requests
from datetime import datetime, timedelta, timezone

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN") or os.getenv("GH_TOKEN")
REPO = os.getenv("GITHUB_REPOSITORY")  # e.g. "org/repo" provided by Actions
SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL")

HEADERS = {"Authorization": f"Bearer {GITHUB_TOKEN}", "Accept": "application/vnd.github+json"}

def iso_to_dt(s):
    return datetime.fromisoformat(s.replace('Z', '+00:00'))

def fetch_runs(workflow_name="CI-CD", days=7):
    url = f"https://api.github.com/repos/{REPO}/actions/runs"
    params = {"per_page": 100}
    runs = []
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    while url:
        r = requests.get(url, headers=HEADERS, params=params)
        r.raise_for_status()
        data = r.json()
        for run in data.get("workflow_runs", []):
            if run.get("name") != workflow_name:
                continue
            created = iso_to_dt(run["created_at"])
            if created < cutoff:
                continue
            runs.append(run)
        # pagination
        url = None
        if "next" in r.links:
            url = r.links["next"]["url"]
    return runs

def summarize(runs):
    total = len(runs)
    success = sum(1 for r in runs if r.get("conclusion") == "success")
    failure = sum(1 for r in runs if r.get("conclusion") in {"failure","cancelled","timed_out"})
    running = sum(1 for r in runs if r.get("status") in {"in_progress","queued"})
    durations = []
    for r in runs:
        if r.get("run_started_at") and r.get("updated_at"):
            start = iso_to_dt(r["run_started_at"])
            end = iso_to_dt(r["updated_at"])
            durations.append((end - start).total_seconds()/60.0)
    avg = round(sum(durations)/len(durations),2) if durations else 0.0
    longest = round(max(durations),2) if durations else 0.0
    shortest = round(min(durations),2) if durations else 0.0
    # Recent failures list
    failed = [r for r in runs if r.get("conclusion") in {"failure","cancelled","timed_out"}]
    fail_lines = []
    for r in failed[:5]:
        sha = r.get("head_sha","")[:7]
        when = iso_to_dt(r["created_at"]).strftime("%Y-%m-%d")
        fail_lines.append(f"- {when} • {sha} • {r.get('conclusion','unknown')}")
    return {
        "total": total,
        "success": success,
        "failure": failure,
        "running": running,
        "avg_min": avg,
        "min_min": shortest,
        "max_min": longest,
        "recent_failures": fail_lines
    }

def post_to_slack(summary):
    if not SLACK_WEBHOOK_URL:
        print("No SLACK_WEBHOOK_URL provided; printing summary instead.")
        print(summary)
        return
    text = (
        f"*Weekly CI Summary* (last 7 days)\n"
        f"• Runs: {summary['total']}  ✓ {summary['success']}  ✗ {summary['failure']}  ⏳ {summary['running']}\n"
        f"• Durations (min): avg {summary['avg_min']}, min {summary['min_min']}, max {summary['max_min']}\n"
    )
    if summary["recent_failures"]:
        text += "*Recent failures*\n" + "\n".join(summary["recent_failures"])
    payload = {"text": text}
    r = requests.post(SLACK_WEBHOOK_URL, json=payload)
    if r.status_code >= 300:
        print("Slack post failed:", r.text, file=sys.stderr)
        sys.exit(1)

def main():
    runs = fetch_runs()
    summary = summarize(runs)
    post_to_slack(summary)

if __name__ == "__main__":
    main()
