def parse_ifc(file_path: str): return {}
