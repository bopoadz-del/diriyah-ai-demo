def summarize_transcript(transcript: str): return {'summary': '', 'decisions': [], 'issues': []}
