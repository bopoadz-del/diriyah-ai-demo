def import_bcf(file_path: str): return []
def export_bcf(issues: list, output_path: str): pass
