def transcribe_audio(file_path: str):
    return {'status':'ok','transcript':'Stub transcription'}
