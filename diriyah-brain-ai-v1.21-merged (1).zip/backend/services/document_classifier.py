def classify_document(file_path: str): return 'Unknown'
