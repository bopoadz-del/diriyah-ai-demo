def import_cobie(file_path: str): return {}
def export_cobie(data: dict, output_path: str): pass
