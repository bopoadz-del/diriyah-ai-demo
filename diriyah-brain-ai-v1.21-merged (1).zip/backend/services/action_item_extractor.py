def extract_actions(text: str): return []
