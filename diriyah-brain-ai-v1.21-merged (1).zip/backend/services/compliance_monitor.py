def check_compliance(document_text: str, rules: list): return []
