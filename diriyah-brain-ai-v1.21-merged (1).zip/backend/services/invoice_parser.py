def parse_invoice(file_path: str): return {'vendor': None}
